from .expds_fast import *

__doc__ = expds_fast.__doc__
if hasattr(expds_fast, "__all__"):
    __all__ = expds_fast.__all__